package com.literalura.challenge.model;

public record AuthorData(
        String name,
        Long birth_year,
        Long death_year
) {
}
